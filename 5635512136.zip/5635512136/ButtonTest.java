import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ButtonTest extends JFrame 
{   private int pressCount = 1;
    JLabel count;
    JTextField counter;
   public ButtonTest()
   {
      
      super( "Testing JButton" ); 
      JPanel p =new JPanel();
    p.setLayout(new BorderLayout());
      Container c = getContentPane();
      c.setLayout( new FlowLayout() );


    // JButton with a string argument
        JButton jb = new JButton( "Count" );
        count = new JLabel("Count:");
        counter = new JTextField(100);
        counter.setEditable(false);
        c.add( count );
        c.add( counter );
        c.add( jb );
      jb.addActionListener( new ActionListener() {
	    public void actionPerformed(ActionEvent e)
	    {  counter.setText(Integer.toString(pressCount++));}
	  } );



    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 	      pack( ); 
       setVisible( true );
   } // end of LabelTest()

  public static void main( String args[] )
   { 
        new ButtonTest(); 
        
        } 

} // end of ButtonTest class
